<?php
    $iconeDelete = "https://d1nhio0ox7pgb.cloudfront.net/_img/g_collection_png/standard/16x16/delete.png";
    $iconAtualiza = "https://cdn-icons-png.flaticon.com/512/126/126794.png";
    $voltarCadastro = "https://cdn-icons-png.flaticon.com/128/7792/7792362.png";
    $cadastrarNovo = "https://cdn.icon-icons.com/icons2/2596/PNG/512/add_one_button_insert_plus_icon_155856.png";
?>